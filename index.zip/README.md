# algorithm_gauss_jordan
Implementation for solve ecuationes linear for gauss jordan method make on javascript, and node-webkit env

![alt text](./icon/gui.png "Logo Title Text 1")




